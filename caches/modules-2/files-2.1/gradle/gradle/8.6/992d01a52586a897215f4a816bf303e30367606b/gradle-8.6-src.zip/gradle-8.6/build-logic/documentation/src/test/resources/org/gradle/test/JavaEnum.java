package org.gradle.test;

public enum JavaEnum {
    A, B
}
